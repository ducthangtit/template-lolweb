
### Where to download the Sketch version of Front? ###

In order to download full sketch version, please open the below link and use the provided password:

Download Link: http://bit.ly/front-template-skecht
Password: 9tpfrontW[jXpskecht(8

The reason why we include Sketch file separately is to reduce the original download package size after purchase.



### Free updates and support ###

We would like to draw your attention to the fact that after purchasing a Front Template copy, you get the right for a lifetime entitlement to download updates for FREE! Need help? For any questions or concerns, reach us out at support@htmlstream.com